--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 17.5 (Debian 17.5-1.pgdg120+1)
-- Dumped by pg_dump version 17.0

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE yourmycelebrity;
--
-- Name: yourmycelebrity; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE yourmycelebrity WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE yourmycelebrity OWNER TO postgres;

\connect yourmycelebrity

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: pg_database_owner
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO pg_database_owner;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: pg_database_owner
--

COMMENT ON SCHEMA public IS 'standard public schema';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: activities; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.activities (
    activity_id integer NOT NULL,
    partner_name character varying,
    activity_type character varying,
    title character varying,
    description character varying,
    contract_date date,
    appointment_date date,
    completion_date date,
    status character varying,
    created_at date,
    update_at date
);


ALTER TABLE public.activities OWNER TO postgres;

--
-- Name: activities_activity_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.activities ALTER COLUMN activity_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.activities_activity_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: artist_profile; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.artist_profile (
    artist_id integer NOT NULL,
    official_name character varying,
    birthdate date,
    type character varying,
    real_name character varying,
    mbti character varying,
    bloodtype character varying,
    debut_date date,
    picture character varying,
    user_id integer NOT NULL,
    native_real_name character varying,
    "height(cm)" character varying,
    "weight(kg)" character varying,
    nationality character varying,
    native_offcial_name character varying
);


ALTER TABLE public.artist_profile OWNER TO postgres;

--
-- Name: artist_artist_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.artist_profile ALTER COLUMN artist_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.artist_artist_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: idol_group; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.idol_group (
    idol_group_id integer NOT NULL,
    group_name character varying,
    debutdate date,
    fandom_name character varying,
    members integer,
    picture character varying,
    group_name_korean character varying,
    group_name_japanese character varying
);


ALTER TABLE public.idol_group OWNER TO postgres;

--
-- Name: artist_group_artist_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.idol_group ALTER COLUMN idol_group_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.artist_group_artist_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: group_members; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.group_members (
    group_id integer NOT NULL,
    idol_id integer NOT NULL,
    "position" character varying,
    debut_date_in_group date,
    artist_id integer NOT NULL
);


ALTER TABLE public.group_members OWNER TO postgres;

--
-- Name: group_members_group_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.group_members ALTER COLUMN group_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.group_members_group_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: makeup_team; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.makeup_team (
    makeupteam_id integer NOT NULL,
    team_name character varying,
    lead_id integer NOT NULL,
    staff_id integer NOT NULL
);


ALTER TABLE public.makeup_team OWNER TO postgres;

--
-- Name: makeup_team_makeupteam_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.makeup_team ALTER COLUMN makeupteam_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.makeup_team_makeupteam_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: manager_team; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.manager_team (
    manager_team_id integer NOT NULL,
    team_name character varying,
    description character varying,
    created_at date,
    update_at date
);


ALTER TABLE public.manager_team OWNER TO postgres;

--
-- Name: manager_team_manager_team_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.manager_team ALTER COLUMN manager_team_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.manager_team_manager_team_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: manager_team_members; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.manager_team_members (
    manager_team_id integer NOT NULL,
    staff_id integer NOT NULL,
    role_in_team character varying,
    join_at date
);


ALTER TABLE public.manager_team_members OWNER TO postgres;

--
-- Name: order; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."order" (
    order_id integer NOT NULL,
    user_id integer NOT NULL,
    order_date date,
    status character varying,
    total_price real,
    discount character varying,
    total_bill real
);


ALTER TABLE public."order" OWNER TO postgres;

--
-- Name: order_detail; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.order_detail (
    orderdetail_id integer NOT NULL,
    order_id integer NOT NULL,
    product_id integer NOT NULL,
    amount integer
);


ALTER TABLE public.order_detail OWNER TO postgres;

--
-- Name: order_detail_orderdetail_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.order_detail ALTER COLUMN orderdetail_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.order_detail_orderdetail_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: order_detail_product_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.order_detail ALTER COLUMN product_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.order_detail_product_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: order_order_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public."order" ALTER COLUMN order_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.order_order_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: product; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.product (
    product_id integer NOT NULL,
    product_name character varying,
    product_artist integer NOT NULL,
    product_price double precision,
    product_picture character varying
);


ALTER TABLE public.product OWNER TO postgres;

--
-- Name: product_product_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.product ALTER COLUMN product_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.product_product_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: schedule; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.schedule (
    exhibit_location character varying,
    official_time time without time zone,
    description_for_work character varying,
    makeup_location character varying,
    description_for_staff character varying,
    artist_id integer NOT NULL,
    makeup_team_id integer NOT NULL,
    activity_id integer NOT NULL,
    is_completed boolean NOT NULL,
    schedule_id integer NOT NULL
);


ALTER TABLE public.schedule OWNER TO postgres;

--
-- Name: schedule_schedule_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.schedule ALTER COLUMN schedule_id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.schedule_schedule_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: staff_profile; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.staff_profile (
    staff_id integer NOT NULL,
    responsibilities character varying,
    user_id integer NOT NULL,
    department character varying
);


ALTER TABLE public.staff_profile OWNER TO postgres;

--
-- Name: COLUMN staff_profile.responsibilities; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.staff_profile.responsibilities IS 'ช่างผม หรือช่างแต่งหน้า หรือ สไตลิส';


--
-- Name: staff_staff_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.staff_profile ALTER COLUMN staff_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.staff_staff_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    username character varying,
    password character varying,
    email character varying,
    role character varying NOT NULL,
    first_name character varying,
    last_name character varying,
    phone character varying,
    address character varying,
    profile_pic character varying,
    created_at date,
    updated_at date,
    user_id integer NOT NULL
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: users_user_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.users ALTER COLUMN user_id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.users_user_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Data for Name: activities; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3477.dat

--
-- Data for Name: artist_profile; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3455.dat

--
-- Data for Name: group_members; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3473.dat

--
-- Data for Name: idol_group; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3464.dat

--
-- Data for Name: makeup_team; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3461.dat

--
-- Data for Name: manager_team; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3479.dat

--
-- Data for Name: manager_team_members; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3462.dat

--
-- Data for Name: order; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3468.dat

--
-- Data for Name: order_detail; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3471.dat

--
-- Data for Name: product; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3466.dat

--
-- Data for Name: schedule; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3457.dat

--
-- Data for Name: staff_profile; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3459.dat

--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3474.dat

--
-- Name: activities_activity_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.activities_activity_id_seq', 1, false);


--
-- Name: artist_artist_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.artist_artist_id_seq', 7, true);


--
-- Name: artist_group_artist_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.artist_group_artist_id_seq', 1, true);


--
-- Name: group_members_group_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.group_members_group_id_seq', 6, true);


--
-- Name: makeup_team_makeupteam_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.makeup_team_makeupteam_id_seq', 1, false);


--
-- Name: manager_team_manager_team_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.manager_team_manager_team_id_seq', 1, false);


--
-- Name: order_detail_orderdetail_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.order_detail_orderdetail_id_seq', 1, false);


--
-- Name: order_detail_product_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.order_detail_product_id_seq', 1, false);


--
-- Name: order_order_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.order_order_id_seq', 1, false);


--
-- Name: product_product_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.product_product_id_seq', 1, false);


--
-- Name: schedule_schedule_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.schedule_schedule_id_seq', 1, false);


--
-- Name: staff_staff_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.staff_staff_id_seq', 1, false);


--
-- Name: users_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.users_user_id_seq', 8, true);


--
-- Name: activities activities_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.activities
    ADD CONSTRAINT activities_pkey PRIMARY KEY (activity_id);


--
-- Name: idol_group artist_group_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.idol_group
    ADD CONSTRAINT artist_group_pk PRIMARY KEY (idol_group_id);


--
-- Name: artist_profile artist_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.artist_profile
    ADD CONSTRAINT artist_pkey PRIMARY KEY (artist_id);


--
-- Name: group_members group_members_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.group_members
    ADD CONSTRAINT group_members_pk PRIMARY KEY (group_id);


--
-- Name: makeup_team makeup_team_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.makeup_team
    ADD CONSTRAINT makeup_team_pk PRIMARY KEY (makeupteam_id);


--
-- Name: manager_team manager_team_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.manager_team
    ADD CONSTRAINT manager_team_pk PRIMARY KEY (manager_team_id);


--
-- Name: order_detail order_detail_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_detail
    ADD CONSTRAINT order_detail_pk PRIMARY KEY (orderdetail_id);


--
-- Name: order order_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."order"
    ADD CONSTRAINT order_pk PRIMARY KEY (order_id);


--
-- Name: product product_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product
    ADD CONSTRAINT product_pk PRIMARY KEY (product_id);


--
-- Name: schedule schedule_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.schedule
    ADD CONSTRAINT schedule_pkey PRIMARY KEY (schedule_id);


--
-- Name: staff_profile staff_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.staff_profile
    ADD CONSTRAINT staff_pk PRIMARY KEY (staff_id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (user_id);


--
-- Name: artist_group_artist_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX artist_group_artist_id_idx ON public.idol_group USING btree (idol_group_id);


--
-- Name: artist_profile artist_profile_users_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.artist_profile
    ADD CONSTRAINT artist_profile_users_fk FOREIGN KEY (user_id) REFERENCES public.users(user_id);


--
-- Name: group_members group_members_artist_profile_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.group_members
    ADD CONSTRAINT group_members_artist_profile_fk FOREIGN KEY (artist_id) REFERENCES public.artist_profile(artist_id);


--
-- Name: group_members group_members_idol_group_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.group_members
    ADD CONSTRAINT group_members_idol_group_fk FOREIGN KEY (idol_id) REFERENCES public.idol_group(idol_group_id);


--
-- Name: makeup_team makeup_team_staff_profile_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.makeup_team
    ADD CONSTRAINT makeup_team_staff_profile_fk FOREIGN KEY (staff_id) REFERENCES public.staff_profile(staff_id);


--
-- Name: makeup_team makeup_team_staff_profile_fk_1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.makeup_team
    ADD CONSTRAINT makeup_team_staff_profile_fk_1 FOREIGN KEY (lead_id) REFERENCES public.staff_profile(staff_id);


--
-- Name: manager_team_members manager_team_members_manager_team_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.manager_team_members
    ADD CONSTRAINT manager_team_members_manager_team_fk FOREIGN KEY (manager_team_id) REFERENCES public.manager_team(manager_team_id);


--
-- Name: manager_team_members manager_team_members_staff_profile_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.manager_team_members
    ADD CONSTRAINT manager_team_members_staff_profile_fk FOREIGN KEY (staff_id) REFERENCES public.staff_profile(staff_id);


--
-- Name: order_detail order_detail_order_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_detail
    ADD CONSTRAINT order_detail_order_fk FOREIGN KEY (order_id) REFERENCES public."order"(order_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: order_detail order_detail_product_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_detail
    ADD CONSTRAINT order_detail_product_fk FOREIGN KEY (product_id) REFERENCES public.product(product_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: order order_users_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."order"
    ADD CONSTRAINT order_users_fk FOREIGN KEY (user_id) REFERENCES public.users(user_id);


--
-- Name: product product_artist_profile_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product
    ADD CONSTRAINT product_artist_profile_fk FOREIGN KEY (product_artist) REFERENCES public.artist_profile(artist_id);


--
-- Name: schedule schedule_activities_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.schedule
    ADD CONSTRAINT schedule_activities_fk FOREIGN KEY (activity_id) REFERENCES public.activities(activity_id);


--
-- Name: schedule schedule_artist_profile_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.schedule
    ADD CONSTRAINT schedule_artist_profile_fk FOREIGN KEY (artist_id) REFERENCES public.artist_profile(artist_id);


--
-- Name: schedule schedule_makeup_team_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.schedule
    ADD CONSTRAINT schedule_makeup_team_fk FOREIGN KEY (makeup_team_id) REFERENCES public.makeup_team(makeupteam_id);


--
-- Name: staff_profile staff_profile_users_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.staff_profile
    ADD CONSTRAINT staff_profile_users_fk FOREIGN KEY (user_id) REFERENCES public.users(user_id);


--
-- PostgreSQL database dump complete
--

